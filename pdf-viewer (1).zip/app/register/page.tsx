import Register from '../../components/Register'

export default function RegisterPage() {
  return (
    <div className="min-h-screen bg-gray-900">
      <Register />
    </div>
  )
}

